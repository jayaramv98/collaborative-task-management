# collaborative-task-management
A Real-Time Collaborative Task Manager

// Express.js, Node.js, MongoDB, GraphQL API
// Plan to add React UI later
