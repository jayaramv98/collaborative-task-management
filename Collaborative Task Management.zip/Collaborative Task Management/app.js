const express = require('express');
const bodyParser = require('body-parser');
const { graphqlHTTP } = require('express-graphql');
const mongoose = require('mongoose');
const authRoute = require('./routes/auth')
const homeRoute = require('./routes/home')
const { addJwtToRequest } = require('./middleware/jwtValidate');
//const taskRoute = require('./routes/task')

const graphqlSchema = require('./graphql/schema/index');
const graphqlResolvers = require('./graphql/resolvers/index');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use('/', homeRoute);
app.use("/home", authRoute)
//app.use("/api/tasks",taskRoute)

app.use('/graphql', addJwtToRequest, graphqlHTTP({
    schema: graphqlSchema,
    rootValue: graphqlResolvers,
    graphiql: true
}));

mongoose.connect(`mongodb+srv://${process.env.MONGO_USER}:${process.env.MONGO_PASSWORD}@cluster0.svnc1im.mongodb.net/${process.env.MONGO_DB}?retryWrites=true&w=majority`).
                then(() => {
                    app.listen(3000);
                }).catch(err => {
                    console.log(err);
                });