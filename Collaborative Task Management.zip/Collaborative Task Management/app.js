const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const mongoose = require('mongoose');
const isAuth = require('./middleware/is-auth');
require('dotenv').config();

const graphqlSchema = require('./graphql/schema/index');
const rootResolver = require('./graphql/resolvers/index');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');

app.use(isAuth);

app.use('/graphql', isAuth, graphqlHTTP({
    schema: graphqlSchema,
    rootValue: rootResolver,
    graphiql: true
}));

mongoose.connect(`mongodb+srv://${process.env.MONGO_USER}:${process.env.MONGO_PASSWORD}@cluster0.svnc1im.mongodb.net/${process.env.MONGO_DB}?retryWrites=true&w=majority`).
                then(() => {
                    app.listen(3000);
                }).catch(err => {
                    console.log(err);
                });