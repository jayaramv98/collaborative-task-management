const User = require('./../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');


const UserController = {
async authenticate (req, res) {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ email: username });
        if (!user) {
            return await res.status(401).json({ error: 'Authentication failed' });
        }
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            return await res.status(401).json({ error: 'Invalid credentials' });
        }
        console.log('Authentication successful');   
        // TODO - secret-key generation for signing JWT
        const token = jwt.sign({ userId: user._id }, 'your-secret-key', {
            expiresIn: '1h',
            });
        res.set('jwt-token', token);
        res.redirect('/graphql');
    } catch (error) {
        console.error('Authentication error:', error);
        return await res.status(500).json({ error: 'Internal server error' });
    }
},

async register(req, res) {
    try {
        console.log(req.body);
        const { email, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ email: email, password: hashedPassword });
        await user.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Registration failed' });
    }
    }
}

module.exports = UserController;