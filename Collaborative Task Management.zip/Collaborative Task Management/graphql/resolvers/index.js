const authResolver = require('./auth');
const tasksResolver = require('./tasks');
const userResolver = require('./user');


const rootResolver = {
    ...authResolver,
    ...tasksResolver,
    ...userResolver
};

module.exports = rootResolver;