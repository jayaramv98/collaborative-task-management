const bcrypt = require('bcryptjs');


const Task = require('../../models/task');
const User = require('../../models/user');

const user = async userId => {
    try {
        const user = await User.findById(userId);
        return { ...user._doc, createdTasks: tasks.bind(this, user._doc.createdTasks)};
    } catch(err) {
        throw err;
    }
}

const tasks = async taskIds => {
    try {
        const tasks = await Task.find({_id: { $in: taskIds } });
        tasks.map(task => {
                return { ...task._doc, creator: user.bind(this, task.creator)}
            })
        return tasks;
    } catch(err) {
        throw err;
    }
}


module.exports = {
    tasks: async () => {
        try {
            const tasks = await Task.find();
            return tasks.map(task => {
                return { ...task._doc, creator: user.bind(this, task.creator) };
            });
        } catch(err) {
            throw err;
        }
    },
    createTask: async (args) => {
        try {
            const task = new Task({
                title: args.taskInput.title,
                description: args.taskInput.description,
                dueDate: new Date(args.taskInput.dueDate),
                asignee: args.taskInput.asignee,
                creator: '65d199805d4bccfb448f3baa'
            });
            let createdTask;
            const result = await task.save();
            const creator = await User.findById('65d199805d4bccfb448f3baa');
            if (!creator) {
                throw new Error('creator not found');
            }
            createdTask = { ...result._doc, creator: user.bind(this, result._doc.creator) };
            creator.createdTasks.push(task);
            await creator.save();
            return createdTask;
        } catch(err) {
            throw err;
        }
    },
    updateTask: async (args) => {
        try {

            console.log(args);
            let where = {};

            if (args.updateWhere._id) {
                where._id = args.updateWhere._id;
            }

            if (args.updateWhere.title) {
                where.title = args.updateWhere.title;
            }

            if (args.updateWhere.description) {
                where.description = args.updateWhere.description;
            }

            if (args.updateWhere.dueDate) {
                where.dueDate = args.updateWhere.dueDate;
            }

            if (args.updateWhere.asignee) {
                where.asignee = args.updateWhere.asignee;
            }

            console.log(where);

            const tasks = (await Task.find(where)).map(task => {
                return task._id;
            });
            console.log(tasks);
            updateDoc = args.taskInput;

            Task.updateMany({_id: {$in: tasks}}, {title: "Dummy"});
        } catch(err) {
            throw err;
        }
    },
    createUser: async (args) => {

        try {
            const user = await User.findOne({email: args.userInput.email});
            if (user) {
                throw new Error('User Exists Already');
            }
            
            const hashedPassword = await bcrypt.hash(args.userInput.password, 12);
            
                const newUser = new User({
                    email: args.userInput.email,
                    password: hashedPassword
                });
                const result = await newUser.save();
                return { ...result._doc };
        } catch (err) {
            throw err;
        }
    }
}