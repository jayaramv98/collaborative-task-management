const bcrypt = require('bcryptjs');
const User = require('../../models/user');
const jwt = require('jsonwebtoken');
require('dotenv').config();
const axios = require('axios');

module.exports = {

    login: async ({ email, password }) => {
        const user = await User.findOne({ email: email });
        if (!user) {
            throw new Error('Authentication failed. User does not exist!');
        }
        const passwordMatch = await bcrypt.compare(password, user.password);
        if (!passwordMatch) {
            throw new Error('Invalid credentials');
        }
        console.log('Authentication successful');

        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        /* const axiosInstance = axios.create({
            baseURL: 'http://localhost:3000/graphql', // Your API base URL
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}` // Add Authorization header with token
            }
          }); */

        return { userId: user._id, token: token, tokenExpiration: 1 };
    },

    createUser: async (args) => {
        try {
            const user = await User.findOne({ email: args.userInputData.email });

            if (user) {
                throw new Error('User Exists Already');
            }

            const hashedPassword = await bcrypt.hash(args.userInputData.password, 12);

            const newUser = new User({
                email: args.userInputData.email,
                password: hashedPassword,
                team: args.userInputData.team,
                role: args.userInputData.role
            });

            const result = await newUser.save();
            return { ...result._doc };

        } catch (err) {
            throw err;
        }
    }

}