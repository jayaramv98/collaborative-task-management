const User = require('../../models/user')
const Task = require('../../models/task')

const tasks = async taskIds => {
    try {
        const tasks = await Task.find({_id: { $in: taskIds } });
        result = tasks.map(task => {
                return transformTask(task);
            })
        return result;
    } catch(err) {  
        throw err;
    }
}

const user = async userId => {
    try {
        const user = await User.findById(userId);
        console.log(user);
        return { ...user, createdTasks: tasks.bind(this, user._doc.createdTasks)};
    } catch(err) {
        throw err;
    }
}

const task = async taskId => {
    try {
        const task = await Task.findById(taskId);
        return transformTask(task);
    } catch(err) {
        throw err;
    }
}

exports.tasks = tasks;
exports.task = task;
exports.user = user;