const {dateToString} = require('../../helpers/date');
const Task = require('../../models/task');
const User = require('../../models/user');
const { user } = require('./binders');

const transformTask = task => {
    console.log(task);
    return {
        ...task,
        dueDate: dateToString(task.dueDate),
        //creator: user.bind(this, task.creator)
    }
}

module.exports = {
    tasks: async (req) => {
        console.log(req);
        /* if (!req.isAuthenticated) {
            throw new Error('Not authorized. Please login first!');
        } */
        try {
            const tasks = await Task.find();
            console.log(tasks);
            return tasks.map(task => {
                return transformTask(task);
            });
        } catch(err) {
            throw err;
        }
    },
    createTask: async (args, req) => {
        /* if (!req.isAuthenticated) {
            throw new Error('Not authorized. Please login first!');
        } */
        console.log(req);
        try {
            const task = new Task({
                title: args.taskInput.title,
                description: args.taskInput.description,
                dueDate: args.taskInput.dueDate,
                asignee: args.taskInput.asignee,
                creator: req.userId
            });
            let createdTask;
            const result = await task.save();
            const creator = await User.findById(req.userId);
            if (!creator) {
                throw new Error('Creator not found');
            }
            createdTask = { ...result._doc, creator: user.bind(this, result._doc.creator) };
            creator.createdTasks.push(task);
            await creator.save();
            return createdTask;
        } catch(err) {
            throw err;
        }
    },
    updateTask: async (args) => {
        try {
            updatedTask = await Task.updateOne({_id: args.taskId}, { $set: args.taskInput });
            if (updatedTask.modifiedCount == 1) {
                return await Task.findById(args.taskId);
            }
        } catch(err) {
            throw err;
        }
    }
}