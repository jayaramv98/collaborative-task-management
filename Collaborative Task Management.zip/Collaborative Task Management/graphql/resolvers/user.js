const User = require('../../models/user');

const user = async userId => {
    try {
        const user = await User.findById(userId);
        return { ...user._doc, createdTasks: tasks.bind(this, user._doc.createdTasks)};
    } catch(err) {
        throw err;
    }
}

