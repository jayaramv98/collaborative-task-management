const { buildSchema } = require('graphql');

module.exports = buildSchema(`
        type Task {
            _id: ID!
            title: String!
            description: String!
            dueDate: String!
            asignee: String,
            creator: User!
        }

        type Team {
            name: String
            members: [ID!]
        }

        type User {
            _id: ID
            email: String
            team: String
            role: String
            createdTasks: [Task!]
        }

        type AuthData {
            userId: ID!
            token: String!
            tokenExpiration: Int!
        }

        type UserTeam {
            team: Team!
            role: String!
          }

        input createTaskInput {
            title: String!
            description: String!
            dueDate: String!
            asignee: String
            team: String
        }

        input updateTaskInput {
            title: String
            description: String
            dueDate: String
            asignee: String
            team: String
        }

        input userInput {
            username: String!
            email: String!
            password: String!
            role: String!
            teams: [UserTeam!]!
        }

        type defaultQueries {
            tasks: [Task!]!
            login(email:String!, password: String!): AuthData
            createUser(userInputData: userInput): User
        }

        type defaultMutations {
            createTask(taskInput: createTaskInput): Task
            updateTask(taskId: ID!, taskInput: updateTaskInput): Task
            deleteTask(taskId: ID!): ID
            deleteTasks(whereInput: updateTaskInput): Int
        }

        schema {
            query: defaultQueries
            mutation: defaultMutations
        }
    `);