const { buildSchema } = require('graphql');

module.exports = buildSchema(`
        type Task {
            _id: ID!
            title: String!
            description: String!
            dueDate: String!
            asignee: String,
            creator: User!
        }

        type User {
            _id: ID!
            email: String!
            password: String,
            createdTasks: [Task!]
        }

        input createTaskInput {
            title: String!
            description: String!
            dueDate: String!
            asignee: String
        }

        input updateWhereInput {
            _id: ID
            title: String
            description: String
            dueDate: String
            asignee: String
        }

        input updateTaskInput {
            title: String
            description: String
            dueDate: String
            asignee: String
        }

        input userInput {
            email: String!
            password: String!
        }

        type defaultQueries {
            tasks: [Task!]!
        }

        type defaultMutations {
            createTask(taskInput: createTaskInput): Task
            updateTask(updateWhere: updateWhereInput, taskInput: updateTaskInput): Task
            createUser(userInput: userInput): User
        }

        schema {
            query: defaultQueries
            mutation: defaultMutations
        }
    `);