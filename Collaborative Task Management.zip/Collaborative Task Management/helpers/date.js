exports.dateToString = date => {
    console.log(date);
    return new Date(date).toISOString();
}