const jwt = require('jsonwebtoken');
const { User } = require('../models/user'); // Import your User model
const JWT_SECRET = require('../config/jwt'); // Import your JWT secret key

// Middleware function to add JWT token to requests
const addJwtToRequest = async (req, res, next) => {
    console.log('addJwtToRequest');
    console.log(JWT_SECRET);
  // Check if Authorization header exists
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    try {
      // Extract JWT token from Authorization header
      const token = req.headers.authorization.split(' ')[1];

      // Verify JWT token
      const decoded = jwt.verify(token, JWT_SECRET);

      // Attach user information to request object
      req.user = await User.findById(decoded.userId); // Assuming userId is stored in the token

      // Move to the next middleware or route handler
      next();
    } catch (error) {
      // Token verification failed
      return res.status(401).json({ error: 'Unauthorized' });
    }
  } else {
    // Authorization header missing or incorrect format
    req.headers.authorization = 'Bearer ' + JWT_SECRET;
    console.log(req.headers);
    next();
    //return res.status(401).json({ error: 'Unauthorized' });
  }
};

module.exports = { addJwtToRequest };
